﻿using CsvHelper;
using Microsoft.EntityFrameworkCore;
using PremierLogic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremierMain
{
    public class PremierDbContext : DbContext
    {
        public ObservableCollection<FootballMatch> Matches { get; set; }

        public PremierDbContext()
        {
            Matches = new ObservableCollection<FootballMatch>();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Usa InMemory como el proveedor de base de datos
            optionsBuilder.UseInMemoryDatabase("InMemoryDatabase");
        }

        public override int SaveChanges()
        {
            int retValue = base.SaveChanges();
            saveToCsv();
            return retValue;
        }

        public override int SaveChanges(bool acceptAllChangesOnSuccess)
        {
            int retValue = base.SaveChanges(acceptAllChangesOnSuccess);
            saveToCsv();
            return retValue;
        }

        private void saveToCsv()
        {
            using (var writer = new StreamWriter(LogicaNegocio.RutaArchivo))
            using (var csvWriter = new CsvWriter(writer, LogicaNegocio.CsvConfig))
            {
                csvWriter.WriteRecords(this.Matches.ToList());
            }
        }
    }
}

