﻿using CsvHelper;

using PremierLogic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PremierMain
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string nombreArchivo = "Premier.csv";
        private string ruta = AppDomain.CurrentDomain.BaseDirectory;

        public MainWindow()
        {
            InitializeComponent();
            fillDataGrid();
        }

        private List<FootballMatch> lstMatches { get; set; }

        private PremierDbContext context = new PremierDbContext();

        private void fillDataGrid()
        {
            this.DataContext = context;
            using (var reader = new StreamReader(LogicaNegocio.RutaArchivo))
            using (var csv = new CsvReader(reader, LogicaNegocio.CsvConfig))
            {
                lstMatches = new List<FootballMatch>(csv.GetRecords<FootballMatch>().ToList());
                lstMatches.ForEach(v => context.Matches.Add(v));
            }
        }
    }
}