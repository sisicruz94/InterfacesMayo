﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremierLogic
{
    public enum ResultType { Half, Full}
   public class FootballMatch
    {
        [Key]
        public string Season { get; set; }
        [Format("dd/MM/yyyy")]
        public DateOnly Date { get; set; }
        [Format("HH:mm")]
        public TimeOnly Time { get; set; }
        [Key]
        public string HomeTeam { get; set; }
        [Key]
        public string AwayTeam { get; set; }
        public byte FullTimeHomeTeamGoals { get; set; }
        public byte FullTimeAwayTeamGoals { get; set; }
        public char FullTimeResult { get; set; }
        public byte HalfTimeHomeTeamGoals { get; set; }
        public byte HalfTimeAwayTeamGoals { get; set; }
        public char HalfTimeResult { get; set; }


        /// <summary>
        /// Método de validación de resultado.
        /// </summary>
        /// <param name="resultType">Tipo de resultado: H para descanso y F para final del partido</param>
        /// <param name="message">En caso de producirse un error de validación, mensaje correspondiente</param>
        /// <returns>Devuelve <b>true</b> si el resultado es correcto, <b>false</b> en caso contrario</returns>
        public bool ValidateResult(ResultType resultType, out string message) 
        {
            bool retValue = false;
            message = string.Empty;
            switch (resultType)
            {
                case ResultType.Half:
                    retValue = validateGenericResult(HalfTimeHomeTeamGoals, HalfTimeAwayTeamGoals, HalfTimeResult, out message);
                    if (!string.IsNullOrEmpty(message))
                        message = string.Concat("Error de validación de resultado en el descanso", message);
                    break;
                case ResultType.Full:
                    retValue = validateGenericResult(FullTimeHomeTeamGoals, FullTimeAwayTeamGoals, FullTimeResult, out message);
                    if (!string.IsNullOrEmpty(message))
                        message = string.Concat("Error de validación de resultado final", message);
                    break;
            }
            return retValue;
        }

        /// <summary>
        /// Valida un resultado de fútbol genérico según los goles del equipo local y el visitante
        /// </summary>
        /// <param name="homeGoals">Goles del equipo local</param>
        /// <param name="awayGoals">Goles del equipo visitante</param>
        /// <param name="result">Resultado: H para triunfo local. D para empate. A para triunfo visitante</param>
        /// <param name="message">En caso de producirse un error de validación, mensaje correspondiente<</param>
        /// <returns>Devuelve <b>true</b> si el resultado es correcto, <b>false</b> en caso contrario</returns>
        private bool validateGenericResult(byte homeGoals, byte awayGoals, char result, out string message) 
        { 
            bool retValue = false;
            message = string.Empty;
            switch (result)
            {
                case 'H':
                    retValue = homeGoals > awayGoals;
                    message = "Victoria local no válida. El número de goles del equipo de casa deben ser mayores que los del visitante";
                    break;
                case 'D':
                    retValue = homeGoals.Equals(awayGoals);
                    message = "Empate no válido. El número de goles de los equipos local y visitante deben ser iguales";
                    break;
                case 'A':
                    retValue = homeGoals < awayGoals;
                    message = "Victoria visitante no válida. El número de goles del equipo de casa deben ser mayores que los del visitante";
                    break;
                default:
                    retValue = false;
                    message = "El resultado introducido no es un tipo conocido. Debe ser H, D o A";
                    break;
            }
            return retValue;
        }

    }
}
